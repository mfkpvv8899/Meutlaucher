package com.meu.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*
import java.text.DateFormat
import java.util.Date

class UninstallActivity : Activity() {

    private class UApp(val label: String, val pkg: String, val icon: Drawable, val time: Long)

    private var apps = listOf<UApp>()
    private val selected = linkedSetOf<String>()
    private val queue = mutableListOf<String>()
    private var query = ""
    private var accent = Color.RED
    private lateinit var listBox: LinearLayout
    private lateinit var btn: TextView
    private val dn by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * dn).toInt()

    private fun rr(fill: Int, rad: Int) = GradientDrawable().apply { setColor(fill); cornerRadius = rad * dn }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        accent = Cfg.i("accent", Color.parseColor("#FF3B3B"))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(40), dp(18), dp(16))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "Desinstalar apps"; textSize = 22f; setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "Voltar"; setTextColor(Color.BLACK); setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rr(accent, 16); setOnClickListener { finish() }
        })
        root.addView(top)

        root.addView(EditText(this).apply {
            hint = "Buscar app"; setHintTextColor(Color.argb(153, 255, 255, 255)); setTextColor(Color.WHITE)
            isSingleLine = true; textSize = 14f
            background = rr(0x26FFFFFF, 12); setPadding(dp(14), dp(10), dp(14), dp(10))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { query = s.toString().trim().lowercase(); render() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(8) })

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(listBox) },
            LinearLayout.LayoutParams(-1, 0, 1f))

        btn = TextView(this).apply {
            gravity = Gravity.CENTER; textSize = 15f; setTextColor(Color.BLACK)
            setPadding(0, dp(14), 0, dp(14)); background = rr(accent, 14)
            setOnClickListener { confirm() }
        }
        root.addView(btn, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        setContentView(root)
        updateBtn()
        load()
    }

    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    private fun load() {
        Thread {
            val pm = packageManager
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val list = pm.queryIntentActivities(intent, 0)
                .filter {
                    it.activityInfo.packageName != packageName &&
                        (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) == 0
                }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    val t = try { pm.getPackageInfo(pkg, 0).firstInstallTime } catch (e: Exception) { 0L }
                    UApp(ri.loadLabel(pm).toString(), pkg, ri.loadIcon(pm), t)
                }
                .sortedByDescending { it.time }
            runOnUiThread {
                if (!isDestroyed) {
                    apps = list
                    selected.retainAll(list.map { it.pkg }.toSet())
                    render()
                    updateBtn()
                }
            }
        }.start()
    }

    private fun render() {
        listBox.removeAllViews()
        val items = apps.filter { query.isEmpty() || it.label.lowercase().contains(query) }
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Nenhum app para desinstalar."; setTextColor(Color.WHITE); setPadding(0, dp(20), 0, 0)
            })
            return
        }
        val df = DateFormat.getDateInstance(DateFormat.SHORT)
        items.forEach { a ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            val cb = CheckBox(this).apply {
                isChecked = selected.contains(a.pkg)
                setOnCheckedChangeListener { _, v ->
                    if (v) selected.add(a.pkg) else selected.remove(a.pkg)
                    updateBtn()
                }
            }
            row.addView(cb)
            row.addView(ImageView(this).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply { text = a.label; setTextColor(Color.WHITE); textSize = 15f; maxLines = 1 })
            if (a.time > 0) col.addView(TextView(this).apply {
                text = "Instalado em " + df.format(Date(a.time)); setTextColor(Color.parseColor("#B9A7D6")); textSize = 12f
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
            row.setOnClickListener { cb.toggle() }
            listBox.addView(row)
        }
    }

    private fun updateBtn() {
        btn.text = if (selected.isEmpty()) "Selecione apps para desinstalar" else "Desinstalar (" + selected.size + ")"
        btn.alpha = if (selected.isEmpty()) 0.5f else 1f
    }

    private fun confirm() {
        if (selected.isEmpty()) {
            Toast.makeText(this, "Marque pelo menos um app", Toast.LENGTH_SHORT).show()
            return
        }
        val names = apps.filter { selected.contains(it.pkg) }.joinToString("\n") { "• " + it.label }
        AlertDialog.Builder(this)
            .setTitle("Desinstalar " + selected.size + " app(s)?")
            .setMessage(names + "\n\nO Android vai pedir a confirmação de cada um.")
            .setPositiveButton("Continuar") { _, _ ->
                queue.clear()
                queue.addAll(selected)
                next()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun next() {
        if (queue.isEmpty()) {
            selected.clear()
            load()
            Toast.makeText(this, "Concluído", Toast.LENGTH_SHORT).show()
            return
        }
        val pkg = queue.removeAt(0)
        try {
            val i = Intent(Intent.ACTION_UNINSTALL_PACKAGE, Uri.parse("package:$pkg"))
            i.putExtra(Intent.EXTRA_RETURN_RESULT, true)
            startActivityForResult(i, 21)
        } catch (e: Exception) {
            next()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 21) return
        if (res == RESULT_OK) next()
        else {
            queue.clear()
            selected.clear()
            load()
        }
    }
}
