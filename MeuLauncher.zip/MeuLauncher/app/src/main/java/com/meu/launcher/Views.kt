package com.meu.launcher

import android.content.Context
import android.graphics.*
import android.view.View
import android.widget.TextClock
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.sin

class OutlineClock(c: Context) : TextClock(c) {
    override fun onDraw(canvas: Canvas) {
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5f
        super.onDraw(canvas)
        paint.style = Paint.Style.FILL
    }
}

class AnalogView(c: Context, private val col: Int) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tick = object : Runnable {
        override fun run() { invalidate(); postDelayed(this, 20000) }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 4f
        val cal = Calendar.getInstance()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = Color.WHITE
        c.drawCircle(cx, cy, r, p)
        val h = (cal.get(Calendar.HOUR) + cal.get(Calendar.MINUTE) / 60f) * 30f
        val m = cal.get(Calendar.MINUTE) * 6f
        hand(c, cx, cy, h, r * 0.5f, 7f)
        hand(c, cx, cy, m, r * 0.8f, 4f)
        p.style = Paint.Style.FILL
        p.color = col
        c.drawCircle(cx, cy, 8f, p)
    }
    private fun hand(c: Canvas, cx: Float, cy: Float, deg: Float, len: Float, w: Float) {
        val a = Math.toRadians(deg.toDouble() - 90.0)
        p.style = Paint.Style.STROKE
        p.strokeWidth = w
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.WHITE
        c.drawLine(cx, cy, (cx + len * cos(a)).toFloat(), (cy + len * sin(a)).toFloat(), p)
    }
}

object Art {
    val names = listOf("Sol carmesim", "Torre", "Meio-tom", "Neon", "Grafite")

    fun make(i: Int, w: Int, h: Int): Bitmap {
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        c.scale(w / 300f, h / 640f)
        fun col(s: String) = Color.parseColor(s)
        fun r(l: Float, t: Float, rt: Float, bt: Float, s: String) {
            p.style = Paint.Style.FILL; p.color = col(s); c.drawRect(l, t, rt, bt, p)
        }
        fun o(x: Float, y: Float, rad: Float, s: String) {
            p.style = Paint.Style.FILL; p.color = col(s); c.drawCircle(x, y, rad, p)
        }
        fun oc(x: Float, y: Float, rad: Float, s: String, sw: Float) {
            p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = col(s); c.drawCircle(x, y, rad, p)
        }
        fun ln(x1: Float, y1: Float, x2: Float, y2: Float, s: String, sw: Float) {
            p.style = Paint.Style.STROKE; p.strokeWidth = sw; p.color = col(s); c.drawLine(x1, y1, x2, y2, p)
        }
        fun poly(s: String, vararg pt: Float) {
            val path = Path()
            path.moveTo(pt[0], pt[1])
            var k = 2
            while (k < pt.size) { path.lineTo(pt[k], pt[k + 1]); k += 2 }
            path.close()
            p.style = Paint.Style.FILL; p.color = col(s); c.drawPath(path, p)
        }
        when (i) {
            0 -> {
                r(0f, 0f, 300f, 640f, "#0A0A0C")
                o(205f, 250f, 125f, "#E11D2E")
                poly("#111114", 0f, 640f, 0f, 440f, 80f, 360f, 140f, 430f, 210f, 330f, 300f, 440f, 300f, 640f)
                r(215f, 330f, 219f, 640f, "#E11D2E"); r(232f, 360f, 234f, 640f, "#E11D2E"); r(246f, 345f, 252f, 640f, "#E11D2E")
                poly("#D9E8E8EA", 150f, 0f, 178f, 0f, 90f, 260f, 62f, 260f)
            }
            1 -> {
                r(0f, 0f, 300f, 640f, "#F1C791")
                r(0f, 380f, 300f, 640f, "#CF6A47")
                poly("#7D1022", 180f, 0f, 300f, 0f, 300f, 600f, 252f, 600f)
                ln(190f, 40f, 290f, 120f, "#4D0A16", 5f); ln(185f, 120f, 290f, 220f, "#4D0A16", 5f)
                ln(200f, 210f, 290f, 320f, "#4D0A16", 5f); ln(215f, 300f, 290f, 420f, "#4D0A16", 5f)
                o(90f, 110f, 5f, "#B3122A"); o(120f, 150f, 3f, "#B3122A"); o(70f, 170f, 4f, "#B3122A")
            }
            2 -> {
                r(0f, 0f, 150f, 640f, "#E9E6E1")
                r(150f, 0f, 300f, 640f, "#D9391F")
                r(0f, 0f, 60f, 640f, "#0C0C0E")
                var y = 4f
                while (y < 640f) {
                    var x = 4f
                    while (x < 60f) { o(x, y, 1.6f, "#E0402A"); x += 8f }
                    y += 8f
                }
                r(150f, 0f, 190f, 640f, "#0C0C0E")
                poly("#0C0C0E", 190f, 640f, 300f, 380f, 300f, 640f)
            }
            3 -> {
                r(0f, 0f, 300f, 640f, "#070B1F")
                oc(150f, 250f, 80f, "#22D3EE", 3f)
                r(0f, 400f, 300f, 640f, "#0B1030")
                for (k in 0 until 8) { val y = 400f + k * k * 4f; ln(0f, y, 300f, y, "#8022D3EE", 1.5f) }
                var x = -300f
                while (x <= 600f) { ln(150f, 400f, x, 640f, "#8022D3EE", 1.5f); x += 60f }
            }
            else -> {
                r(0f, 0f, 300f, 640f, "#1B1B1F")
                ln(200f, 80f, 140f, 220f, "#ECECEC", 4f); ln(140f, 220f, 190f, 220f, "#ECECEC", 4f); ln(190f, 220f, 130f, 360f, "#ECECEC", 4f)
                ln(250f, 400f, 190f, 520f, "#ECECEC", 4f); ln(190f, 520f, 235f, 520f, "#ECECEC", 4f); ln(235f, 520f, 180f, 620f, "#ECECEC", 4f)
                oc(230f, 130f, 30f, "#888888", 3f)
                c.save(); c.rotate(-15f, 85f, 465f)
                p.style = Paint.Style.STROKE; p.strokeWidth = 3f; p.color = col("#ECECEC")
                c.drawRoundRect(60f, 440f, 110f, 490f, 8f, 8f, p)
                c.restore()
                o(85f, 465f, 4f, "#ECECEC")
            }
        }
        return b
    }
}
