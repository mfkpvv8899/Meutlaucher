package com.meu.launcher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView

class AutoClickService : AccessibilityService() {

    companion object { var instance: AutoClickService? = null }

    private var wm: WindowManager? = null
    private var bar: View? = null
    private var target: View? = null
    private var tp: WindowManager.LayoutParams? = null
    private var play: TextView? = null
    private var running = false
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            click()
            h.postDelayed(this, Cfg.i("acms", 500).toLong().coerceAtLeast(50L))
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        Cfg.init(this)
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Cfg.b("acshow", false)) showControls()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideControls()
        instance = null
        return super.onUnbind(intent)
    }

    private fun lp(w: Int, hh: Int) = WindowManager.LayoutParams(
        w, hh, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun drag(handle: View, root: View, p: WindowManager.LayoutParams) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = p.x; oy = p.y }
                MotionEvent.ACTION_MOVE -> {
                    p.x = ox + (e.rawX - sx).toInt()
                    p.y = oy + (e.rawY - sy).toInt()
                    wm?.updateViewLayout(root, p)
                }
            }
            true
        }
    }

    fun showControls() {
        if (bar != null) return
        val w = wm ?: return
        val size = dp(48)

        val t = TextView(this).apply {
            text = "+"; gravity = Gravity.CENTER; textSize = 22f; setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(150, 255, 59, 59))
                setStroke(dp(2), Color.WHITE)
            }
        }
        val tpl = lp(size, size).apply { x = dp(180); y = dp(380) }
        drag(t, t, tpl)
        w.addView(t, tpl)
        target = t
        tp = tpl

        val b = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply { setColor(Color.argb(230, 21, 15, 31)); cornerRadius = dp(20).toFloat() }
        }
        fun item(txt: String, color: Int) = TextView(this).apply {
            text = txt; textSize = 14f; setTextColor(color); setPadding(dp(10), dp(8), dp(10), dp(8))
        }
        val handle = item("≡", Color.WHITE)
        val pl = item("Iniciar", Color.parseColor("#FF3B3B"))
        val close = item("✕", Color.WHITE)
        pl.setOnClickListener { if (running) stop() else start() }
        close.setOnClickListener { Cfg.put("acshow", false); hideControls() }
        b.addView(handle); b.addView(pl); b.addView(close)
        val bpl = lp(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { x = dp(16); y = dp(140) }
        drag(handle, b, bpl)
        w.addView(b, bpl)
        bar = b
        play = pl
    }

    fun hideControls() {
        stop()
        try { target?.let { wm?.removeView(it) } } catch (e: Exception) {}
        try { bar?.let { wm?.removeView(it) } } catch (e: Exception) {}
        target = null
        bar = null
        tp = null
        play = null
    }

    private fun start() {
        running = true
        play?.text = "Parar"
        setTouchable(false)
        h.postDelayed(loop, 300)
    }

    private fun stop() {
        running = false
        h.removeCallbacks(loop)
        play?.text = "Iniciar"
        setTouchable(true)
    }

    private fun setTouchable(t: Boolean) {
        val p = tp ?: return
        val v = target ?: return
        p.flags = if (t) p.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        else p.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        wm?.updateViewLayout(v, p)
    }

    private fun click() {
        val p = tp ?: return
        val path = Path().apply { moveTo(p.x + p.width / 2f, p.y + p.height / 2f) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40))
            .build()
        dispatchGesture(g, null, null)
    }
}
