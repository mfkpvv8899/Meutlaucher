package com.meu.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import java.io.File

class SettingsActivity : Activity() {

    private lateinit var sv: ScrollView
    private lateinit var box: LinearLayout
    private var accent = Color.RED
    private val dn by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * dn).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        build()
    }

    @Suppress("DEPRECATION")
    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
    }

    private fun rebuild() {
        val y = sv.scrollY
        build()
        sv.post { sv.scrollTo(0, y) }
    }

    private fun rr(fill: Int, rad: Int, stroke: Int = 0, sw: Int = 0) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = rad * dn
        if (sw > 0) setStroke(dp(sw), stroke)
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 13f; setTextColor(Color.parseColor("#B9A7D6")); setPadding(0, dp(18), 0, dp(8))
    }

    private fun build() {
        accent = Cfg.i("accent", Color.parseColor("#FF3B3B"))
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(40), dp(18), dp(40)) }
        sv = ScrollView(this).apply { addView(box) }
        setContentView(sv)

        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply { text = "Configurações"; textSize = 22f; setTextColor(Color.WHITE) },
            LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "Concluir"; setTextColor(Color.BLACK); setPadding(dp(14), dp(8), dp(14), dp(8))
            background = rr(accent, 16); setOnClickListener { finish() }
        })
        box.addView(top)

        box.addView(label("Layout"))
        choice("layout", "anime", listOf("anime" to "Anime futurista", "grade" to "Grade de apps"))

        box.addView(label("Estilo do sistema"))
        choice("style", "moderno", listOf("moderno" to "Moderno", "clean" to "Clean", "futurista" to "Futurista"))

        box.addView(label("Wallpaper"))
        wallpapers()

        box.addView(label("Cor de destaque"))
        colors()

        box.addView(label("Posição do painel (anime)"))
        choice("side", "l", listOf("l" to "Esquerda", "r" to "Direita"))

        box.addView(label("Relógio"))
        choice("clock", "stencil", listOf("stencil" to "Stencil", "cheio" to "Cheio", "compacto" to "Compacto",
            "analogico" to "Analógico", "oculto" to "Oculto"))

        box.addView(label("Tamanho e transparência"))
        seek("ts", 10, 18, 12, " sp", "Tamanho do texto")
        seek("pa", 0, 90, 50, "%", "Transparência do fundo")

        box.addView(label("Opções"))
        sw("trans", false, "Apps transparentes (sem caixa)")
        sw("anim", true, "Animações")
        sw("wx", true, "Mostrar bateria")
        sw("sr", true, "Mostrar busca")

        box.addView(label("Tela esticada"))
        stretchSection()

        box.addView(label("Janela flutuante"))
        sw("float", false, "Abrir apps em janela flutuante")
        seek("fw", 30, 100, 70, "%", "Largura da janela")
        seek("fh", 30, 100, 60, "%", "Altura da janela")
        box.addView(note("Só funciona se o celular permitir janelas livres. Em Opções do desenvolvedor, ligue \"Ativar janelas de forma livre\" e \"Forçar atividades a serem redimensionáveis\", e reinicie. No Samsung, o modo DeX também ajuda. Para testar, segure um app e escolha Abrir em janela flutuante."))

        box.addView(label("Auto click"))
        box.addView(note("1) Toque em Ativar acessibilidade e ligue o Node Auto Click. 2) Ligue o controle flutuante. 3) Arraste o alvo (+) até onde quer clicar e toque em Iniciar."))
        box.addView(TextView(this).apply {
            text = "Ativar acessibilidade"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12)); background = rr(0x26FFFFFF, 12)
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(Switch(this).apply {
            text = "Mostrar controle flutuante"; setTextColor(Color.WHITE); isChecked = Cfg.b("acshow", false)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, v ->
                Cfg.put("acshow", v)
                val s = AutoClickService.instance
                if (v) {
                    if (s != null) s.showControls()
                    else Toast.makeText(this@SettingsActivity, "Ative o Node Auto Click em Acessibilidade primeiro", Toast.LENGTH_LONG).show()
                } else s?.hideControls()
            }
        })
        seek("acms", 50, 3000, 500, " ms", "Intervalo entre cliques")

        box.addView(label("Privacidade"))
        sw("hchip", true, "Mostrar aba Ocultos")
        box.addView(TextView(this).apply {
            text = "Alterar senha"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12)); background = rr(0x26FFFFFF, 12)
            setOnClickListener { askPin(this@SettingsActivity, "Senha atual") { newPin() } }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        box.addView(label("Websites"))
        Cfg.sites.forEach { (n, u) ->
            val r = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6)) }
            r.addView(TextView(this).apply { text = "$n  ·  $u"; setTextColor(Color.WHITE); textSize = 14f },
                LinearLayout.LayoutParams(0, -2, 1f))
            r.addView(TextView(this).apply {
                text = "Remover"; setTextColor(accent)
                setOnClickListener { Cfg.sites = Cfg.sites.filter { s -> s.second != u }; rebuild() }
            })
            box.addView(r)
        }
        box.addView(TextView(this).apply {
            text = "+ Adicionar site"; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12)); background = rr(0, 12, accent, 1)
            setOnClickListener { addSite() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun choice(key: String, def: String, opts: List<Pair<String, String>>) {
        opts.chunked(3).forEach { chunk ->
            val row = LinearLayout(this)
            chunk.forEach { (v, n) ->
                val on = Cfg.s(key, def) == v
                val t = TextView(this).apply {
                    text = n; gravity = Gravity.CENTER; textSize = 13f
                    setTextColor(if (on) Color.BLACK else Color.WHITE)
                    background = rr(if (on) accent else 0x26FFFFFF, 12)
                    setPadding(0, dp(10), 0, dp(10))
                    setOnClickListener { Cfg.put(key, v); rebuild() }
                }
                row.addView(t, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(3)) })
            }
            box.addView(row)
        }
    }

    private fun wallpapers() {
        val cur = Cfg.i("wp", 0)
        val row = LinearLayout(this)
        for (i in 0 until 5) row.addView(thumb(Art.make(i, 90, 200), cur == i) { Cfg.put("wp", i); rebuild() },
            LinearLayout.LayoutParams(0, dp(96), 1f).apply { setMargins(dp(2), 0, dp(2), 0) })
        box.addView(row)
        box.addView(TextView(this).apply {
            text = "Escolher da galeria"; setTextColor(if (cur == 5) Color.BLACK else Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12)); background = rr(if (cur == 5) accent else 0x26FFFFFF, 12)
            setOnClickListener {
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("image/*")
                startActivityForResult(i, 7)
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
    }

    private fun thumb(b: Bitmap, on: Boolean, click: () -> Unit): ImageView = ImageView(this).apply {
        setImageBitmap(b)
        scaleType = ImageView.ScaleType.CENTER_CROP
        setPadding(dp(2), dp(2), dp(2), dp(2))
        background = rr(if (on) accent else Color.TRANSPARENT, 8)
        setOnClickListener { click() }
    }

    private fun colors() {
        val list = listOf("#FF3B3B", "#22D3EE", "#FACC15", "#A855F7", "#F5F5F5", "#22C55E", "#EC4899")
        val row = LinearLayout(this)
        list.forEach { s ->
            val c = Color.parseColor(s)
            val v = android.view.View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    if (c == accent) setStroke(dp(3), Color.WHITE)
                }
                setOnClickListener { Cfg.put("accent", c); rebuild() }
            }
            row.addView(v, LinearLayout.LayoutParams(dp(38), dp(38)).apply { setMargins(dp(4), 0, dp(4), 0) })
        }
        box.addView(row)
    }

    private fun seek(key: String, min: Int, max: Int, def: Int, unit: String, title: String) {
        val v = Cfg.i(key, def)
        val head = TextView(this).apply { text = "$title: $v$unit"; setTextColor(Color.WHITE); textSize = 14f; setPadding(0, dp(8), 0, 0) }
        val bar = SeekBar(this)
        bar.max = max - min
        bar.progress = v - min
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                Cfg.put(key, p + min)
                head.text = "$title: ${p + min}$unit"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(head)
        box.addView(bar)
    }

    private fun sw(key: String, def: Boolean, title: String) {
        box.addView(Switch(this).apply {
            text = title; setTextColor(Color.WHITE); isChecked = Cfg.b(key, def)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, v -> Cfg.put(key, v) }
        })
    }

    private fun note(t: String) = TextView(this).apply {
        text = t; textSize = 12f; setTextColor(Color.parseColor("#B9A7D6")); setPadding(0, dp(4), 0, dp(4))
    }

    private fun numField(key: String, def: Int, h: String) = EditText(this).apply {
        inputType = InputType.TYPE_CLASS_NUMBER
        hint = h
        setText(Cfg.i(key, def).toString())
        setTextColor(Color.WHITE)
        setHintTextColor(Color.argb(153, 255, 255, 255))
        background = rr(0x26FFFFFF, 12)
        setPadding(dp(12), dp(10), dp(12), dp(10))
    }

    private fun stretchSection() {
        sw("stretch", false, "Ativar tela esticada")
        val ew = numField("vw", 720, "Largura (W)")
        val eh = numField("vh", 1280, "Altura (H)")
        val row = LinearLayout(this)
        row.addView(ew, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        row.addView(eh, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(6) })
        box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val presets = LinearLayout(this)
        listOf(540 to 960, 720 to 1280, 1080 to 1920, 1080 to 1080).forEach { (w, h) ->
            presets.addView(TextView(this).apply {
                text = "$w×$h"; textSize = 12f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                setPadding(0, dp(8), 0, dp(8)); background = rr(0x1AFFFFFF, 10)
                setOnClickListener { ew.setText(w.toString()); eh.setText(h.toString()) }
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(2), dp(6), dp(2), 0) })
        }
        box.addView(presets)
        box.addView(TextView(this).apply {
            text = "Aplicar tamanho"; setTextColor(Color.BLACK); gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12)); background = rr(accent, 12)
            setOnClickListener {
                val w = (ew.text.toString().toIntOrNull() ?: 720).coerceIn(320, 4000)
                val h = (eh.text.toString().toIntOrNull() ?: 1280).coerceIn(320, 4000)
                Cfg.put("vw", w); Cfg.put("vh", h)
                Toast.makeText(this@SettingsActivity, "Aplicado: $w×$h", Toast.LENGTH_SHORT).show()
                rebuild()
            }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        box.addView(note("Isso estica só o visual do Node. Para mudar a resolução do sistema inteiro, use no computador: adb shell wm size LARGURAxALTURA (e adb shell wm size reset para voltar)."))
    }

    private fun newPin() {
        val e = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "Nova senha (mínimo 4 dígitos)"
        }
        AlertDialog.Builder(this).setTitle("Nova senha").setView(e)
            .setPositiveButton("Salvar") { _, _ ->
                val v = e.text.toString()
                if (v.length >= 4) { Cfg.put("pin", v); Toast.makeText(this, "Senha alterada", Toast.LENGTH_SHORT).show() }
                else Toast.makeText(this, "Use pelo menos 4 dígitos", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun addSite() {
        val n = EditText(this).apply { hint = "Nome (ex.: YouTube)" }
        val u = EditText(this).apply { hint = "Endereço (ex.: youtube.com)"; inputType = InputType.TYPE_TEXT_VARIATION_URI }
        val lay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(n); addView(u)
        }
        AlertDialog.Builder(this).setTitle("Adicionar site").setView(lay)
            .setPositiveButton("Adicionar") { _, _ ->
                val nm = n.text.toString().replace("|", "").trim()
                val ur = u.text.toString().replace("|", "").trim()
                if (nm.isNotEmpty() && ur.isNotEmpty()) { Cfg.sites = Cfg.sites + (nm to ur); rebuild() }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (req != 7 || res != RESULT_OK || uri == null) return
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            var s = 1
            while (maxOf(o.outWidth, o.outHeight) / s > 2200) s *= 2
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                ?: return
            File(filesDir, "wall.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            Cfg.put("wp", 5)
            rebuild()
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível usar essa imagem", Toast.LENGTH_SHORT).show()
        }
    }
}
