package com.meu.launcher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.Drawable

data class Item(val label: String, val pkg: String?, val url: String?, val icon: Drawable, val cat: String)

val CATS = listOf(
    "jogos" to "Jogos", "steam" to "Steam", "social" to "Social mídia", "ia" to "IA",
    "padroes" to "Apps padrões", "sites" to "Websites", "outros" to "Outros"
)

object Cfg {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("node", Context.MODE_PRIVATE)
    }
    fun s(k: String, d: String): String = sp.getString(k, d) ?: d
    fun i(k: String, d: Int): Int = sp.getInt(k, d)
    fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun put(k: String, v: Any) {
        val e = sp.edit()
        when (v) {
            is String -> e.putString(k, v)
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
        }
        e.apply()
    }
    var sites: List<Pair<String, String>>
        get() = s("sites", "").lines().filter { it.contains("|") }
            .map { it.substringBefore("|") to it.substringAfter("|") }
        set(v) = put("sites", v.joinToString("\n") { it.first + "|" + it.second })
}
