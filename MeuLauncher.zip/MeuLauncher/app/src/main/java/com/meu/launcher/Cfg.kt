package com.meu.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.text.InputFilter
import android.text.InputType
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.Toast
import android.content.SharedPreferences
import android.graphics.drawable.Drawable

data class Item(val label: String, val pkg: String?, val url: String?, val icon: Drawable, val cat: String)

val CATS = listOf(
    "jogos" to "Jogos", "steam" to "Steam", "social" to "Social mídia", "ia" to "IA",
    "padroes" to "Apps padrões", "sites" to "Websites", "outros" to "Outros"
)

object Cfg {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("node", Context.MODE_PRIVATE)
    }
    fun s(k: String, d: String): String = sp.getString(k, d) ?: d
    fun i(k: String, d: Int): Int = sp.getInt(k, d)
    fun b(k: String, d: Boolean): Boolean = sp.getBoolean(k, d)
    fun put(k: String, v: Any) {
        val e = sp.edit()
        when (v) {
            is String -> e.putString(k, v)
            is Int -> e.putInt(k, v)
            is Boolean -> e.putBoolean(k, v)
        }
        e.apply()
    }
    fun hidden(): Set<String> = s("hidden", "").split("\n").filter { it.isNotEmpty() }.toSet()
    fun setHidden(v: Set<String>) = put("hidden", v.joinToString("\n"))
    var sites: List<Pair<String, String>>
        get() = s("sites", "").lines().filter { it.contains("|") }
            .map { it.substringBefore("|") to it.substringAfter("|") }
        set(v) = put("sites", v.joinToString("\n") { it.first + "|" + it.second })
}

fun askPin(a: Activity, title: String, ok: () -> Unit) {
    val e = EditText(a).apply {
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        hint = "Senha"
        filters = arrayOf(InputFilter.LengthFilter(12))
    }
    val pad = (20 * a.resources.displayMetrics.density).toInt()
    val box = FrameLayout(a).apply { setPadding(pad, pad / 2, pad, 0); addView(e) }
    AlertDialog.Builder(a).setTitle(title).setView(box)
        .setPositiveButton("Entrar") { _, _ ->
            if (e.text.toString() == Cfg.s("pin", "1232")) ok()
            else Toast.makeText(a, "Senha incorreta", Toast.LENGTH_SHORT).show()
        }
        .setNegativeButton("Cancelar", null).show()
}
