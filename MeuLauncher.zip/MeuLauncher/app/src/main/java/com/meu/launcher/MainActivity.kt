package com.meu.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.PopupMenu
import android.widget.TextView

data class AppInfo(val label: String, val pkg: String, val icon: Drawable)

class MainActivity : Activity() {

    private var all = listOf<AppInfo>()
    private var shown = listOf<AppInfo>()
    private lateinit var search: EditText

    private val adapter = object : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, parent: ViewGroup): View {
            val view = v ?: LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
            val app = shown[i]
            view.findViewById<ImageView>(R.id.icon).setImageDrawable(app.icon)
            view.findViewById<TextView>(R.id.label).text = app.label
            return view
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        search = findViewById(R.id.search)
        val grid = findViewById<GridView>(R.id.grid)
        grid.adapter = adapter

        grid.setOnItemClickListener { _, _, i, _ -> open(shown[i]) }
        grid.setOnItemLongClickListener { _, view, i, _ -> menu(view, shown[i]); true }

        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = filter(s.toString())
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        search.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_DONE && shown.isNotEmpty()) open(shown[0])
            true
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
    }

    // Botão Home: limpa a busca e volta ao topo
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        search.setText("")
        search.clearFocus()
        findViewById<GridView>(R.id.grid).setSelection(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Launcher não fecha com Voltar
        if (search.text.isNotEmpty()) search.setText("")
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val px = (58 * resources.displayMetrics.density).toInt()
        all = pm.queryIntentActivities(intent, 0)
            .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName, squareIcon(it.loadIcon(pm), px)) }
            .filter { it.pkg != packageName }
            .sortedBy { it.label.lowercase() }
        filter(search.text.toString())
    }

    // Deixa todo ícone quadrado, ignorando a máscara redonda do sistema
    private fun squareIcon(d: Drawable, size: Int): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(0xFF1A0F2B.toInt())
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            val full = (size * 108f / 72f).toInt()
            val off = (full - size) / 2f
            c.translate(-off, -off)
            d.background?.let { it.setBounds(0, 0, full, full); it.draw(c) }
            d.foreground?.let { it.setBounds(0, 0, full, full); it.draw(c) }
        } else {
            val p = size / 8
            d.setBounds(p, p, size - p, size - p)
            d.draw(c)
        }
        return BitmapDrawable(resources, bmp)
    }

    private fun filter(q: String) {
        val t = q.trim().lowercase()
        shown = if (t.isEmpty()) all else all.filter { it.label.lowercase().contains(t) }
        adapter.notifyDataSetChanged()
    }

    private fun open(app: AppInfo) {
        packageManager.getLaunchIntentForPackage(app.pkg)?.let { startActivity(it) }
    }

    private fun menu(anchor: View, app: AppInfo) {
        PopupMenu(this, anchor).apply {
            menu.add("Informações do app")
            menu.add("Desinstalar")
            setOnMenuItemClickListener {
                val uri = Uri.parse("package:${app.pkg}")
                if (it.title == "Desinstalar") startActivity(Intent(Intent.ACTION_DELETE, uri))
                else startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                true
            }
            show()
        }
    }
}
