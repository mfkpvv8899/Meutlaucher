package com.meu.launcher

import android.app.Activity
import android.app.ActivityOptions
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.ResolveInfo
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.*
import java.io.File

class MainActivity : Activity() {

    private lateinit var wall: ImageView
    private lateinit var content: FrameLayout
    private lateinit var listBox: LinearLayout
    private var all = listOf<Item>()
    private var filter = "todos"
    private var query = ""
    private var accent = Color.RED
    private var anime = true
    private var insetTop = 0
    private var insetBottom = 0
    private var unlocked = false
    private val chipViews = mutableMapOf<String, TextView>()
    private var cacheKey = ""
    private var cacheBmp: Bitmap? = null
    private val dn by lazy { resources.displayMetrics.density }
    private fun dp(v: Int) = (v * dn).toInt()

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Cfg.init(this)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        val root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        content = FrameLayout(this)
        root.addView(wall, FrameLayout.LayoutParams(-1, -1))
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.setOnApplyWindowInsetsListener { _, ins ->
            val t = ins.systemWindowInsetTop
            val b = ins.systemWindowInsetBottom
            if (t != insetTop || b != insetBottom) { insetTop = t; insetBottom = b; buildScreen() }
            ins
        }
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        buildScreen()
    }

    override fun onPause() {
        super.onPause()
        unlocked = false
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        unlocked = false
        query = ""
        filter = "todos"
        buildScreen()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {}

    private val gd by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                val dx = e2.x - (e1?.x ?: e2.x)
                val dy = e2.y - (e1?.y ?: e2.y)
                if (dx < -dp(110) && Math.abs(dx) > Math.abs(dy) * 1.8f && vx < -900f) {
                    openSettings()
                    return true
                }
                return false
            }
        })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gd.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    @Suppress("DEPRECATION")
    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
    }

    // ---------- dados ----------

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val px = dp(56)
        val tr = Cfg.b("trans", false)
        val apps = pm.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                Item(ri.loadLabel(pm).toString(), pkg, null, squareIcon(ri.loadIcon(pm), px, tr))
            }
        val accentNow = Cfg.i("accent", Color.parseColor("#FF3B3B"))
        val sites = Cfg.sites.map { (n, u) -> Item(n, null, u, letterIcon(n, px, accentNow)) }
        all = (apps + sites).sortedBy { it.label.lowercase() }
    }

    private fun squareIcon(d: Drawable, size: Int, trans: Boolean): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (Build.VERSION.SDK_INT >= 26 && d is AdaptiveIconDrawable) {
            val full = (size * 108f / 72f).toInt()
            val off = (full - size) / 2f
            c.translate(-off, -off)
            if (!trans) d.background?.let { it.setBounds(0, 0, full, full); it.draw(c) }
            d.foreground?.let { it.setBounds(0, 0, full, full); it.draw(c) }
        } else {
            val p = size / 10
            d.setBounds(p, p, size - p, size - p)
            d.draw(c)
        }
        return BitmapDrawable(resources, bmp)
    }

    private fun letterIcon(name: String, size: Int, color: Int): Drawable {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        p.textSize = size * 0.6f
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        c.drawText(name.take(1).uppercase(), size / 2f, size / 2f - (p.ascent() + p.descent()) / 2f, p)
        return BitmapDrawable(resources, bmp)
    }

    private fun visible(): List<Item> {
        val hid = Cfg.hidden()
        val showHid = filter == "ocultos" && unlocked
        return all.filter {
            val isHid = it.pkg != null && hid.contains(it.pkg)
            isHid == showHid &&
                (query.isBlank() || it.label.lowercase().contains(query.trim().lowercase()))
        }
    }

    private fun openHidden() {
        val go = { unlocked = true; filter = "ocultos"; if (chipViews.isNotEmpty()) styleChips(); refreshList() }
        if (unlocked) go() else askPin(this, "Apps ocultos", go)
    }

    private fun wallpaper(): Bitmap {
        val i = Cfg.i("wp", 0)
        val f = File(filesDir, "wall.jpg")
        val key = if (i == 5 && f.exists()) "f" + f.lastModified() else "p" + i.coerceIn(0, 4)
        cacheBmp?.let { if (key == cacheKey) return it }
        val bmp = if (key.startsWith("f")) (BitmapFactory.decodeFile(f.path) ?: Art.make(0, 540, 1170))
        else Art.make(i.coerceIn(0, 4), 540, 1170)
        cacheKey = key
        cacheBmp = bmp
        return bmp
    }

    // ---------- tela ----------

    private fun rr(fill: Int, stroke: Int, sw: Float, rad: Float) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = rad * dn
        if (sw > 0f) setStroke((sw * dn).toInt().coerceAtLeast(1), stroke)
    }

    private fun buildScreen() {
        accent = Cfg.i("accent", Color.parseColor("#FF3B3B"))
        anime = Cfg.s("layout", "anime") == "anime"
        if (filter == "ocultos" && !unlocked) filter = "todos"
        wall.setImageBitmap(wallpaper())
        content.removeAllViews()
        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels
        var vw = sw
        var vh = sh
        if (Cfg.b("stretch", false)) {
            vw = Cfg.i("vw", 720).coerceIn(320, 4000)
            vh = Cfg.i("vh", 1280).coerceIn(320, 4000)
        }
        val ky = sh.toFloat() / vh
        content.layoutParams = if (Cfg.b("stretch", false)) FrameLayout.LayoutParams(vw, vh) else FrameLayout.LayoutParams(-1, -1)
        content.pivotX = 0f
        content.pivotY = 0f
        content.scaleX = sw.toFloat() / vw
        content.scaleY = ky
        val iT = (insetTop / ky).toInt()
        val iB = (insetBottom / ky).toInt()

        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.setPadding(dp(14), iT + dp(18), dp(14), iB + dp(12))
        col.setBackgroundColor(Color.argb(Cfg.i("pa", 50) * 255 / 100, 0, 0, 0))
        if (anime) {
            val w = (vw * 0.66f).toInt()
            val g = if (Cfg.s("side", "l") == "l") Gravity.START else Gravity.END
            content.addView(col, FrameLayout.LayoutParams(w, -1).apply { gravity = g })
        } else {
            content.addView(col, FrameLayout.LayoutParams(-1, -1))
        }

        addWidgets(col)
        col.addView(chips(), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(6) })

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listBox.setPadding(0, 0, 0, dp(70))
        val sv = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(listBox) }
        col.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(View(this).apply { background = rr(accent, 0, 0f, 2f); alpha = 0.6f },
            FrameLayout.LayoutParams(dp(4), dp(48)).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                rightMargin = dp(2)
            })
        refreshList()
    }

    private fun batteryText(): String {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val l = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val s = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (l < 0 || s <= 0) "BAT" else "BAT " + (l * 100 / s) + "%"
    }

    private fun clock(fmt: String, sp: Float, outline: Boolean): TextClock {
        val t = if (outline) OutlineClock(this) else TextClock(this)
        t.format12Hour = fmt
        t.format24Hour = fmt
        t.textSize = sp
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        t.includeFontPadding = false
        return t
    }

    private fun clockView(): View? = when (Cfg.s("clock", "stencil")) {
        "oculto" -> null
        "compacto" -> clock("HH:mm", 36f, false)
        "analogico" -> AnalogView(this, accent).apply { layoutParams = LinearLayout.LayoutParams(dp(120), dp(120)) }
        else -> LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(clock("HH", 62f, false))
            addView(clock("mm", 62f, Cfg.s("clock", "stencil") == "stencil"),
                LinearLayout.LayoutParams(-2, -2).apply { topMargin = -dp(8) })
        }
    }

    private fun addWidgets(col: LinearLayout) {
        if (Cfg.b("wx", true)) {
            col.addView(TextView(this).apply {
                text = batteryText(); textSize = 11f; setTextColor(Color.WHITE); letterSpacing = 0.08f
                setPadding(dp(8), dp(2), dp(8), dp(2)); background = rr(0, accent, 1f, 8f)
                setOnLongClickListener { openHidden(); true }
            }, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(6) })
        }
        clockView()?.let { col.addView(it) }
        if (Cfg.s("clock", "stencil") != "oculto") {
            col.addView(TextClock(this).apply {
                format12Hour = "EEE / d / MMM"; format24Hour = "EEE / d / MMM"
                textSize = 14f; setTextColor(Color.WHITE); letterSpacing = 0.05f
                setOnLongClickListener { openHidden(); true }
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(2); bottomMargin = dp(8) })
        }
        if (Cfg.b("sr", true)) {
            val e = EditText(this).apply {
                hint = "Buscar"
                setHintTextColor(Color.argb(153, 255, 255, 255))
                setTextColor(Color.WHITE)
                textSize = 14f
                isSingleLine = true
                imeOptions = EditorInfo.IME_ACTION_DONE
                background = rr(0, accent, 1f, 18f)
                setPadding(dp(14), dp(6), dp(14), dp(6))
                setText(query)
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { query = s.toString(); refreshList() }
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                })
                setOnEditorActionListener { _, _, _ -> visible().firstOrNull()?.let { open(it) }; true }
            }
            col.addView(e, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun chips(): View {
        chipViews.clear()
        val row = LinearLayout(this)
        val extra = if (Cfg.b("hchip", true)) listOf("ocultos" to "Ocultos") else emptyList()
        val keys = listOf("todos" to "Todos") + extra
        keys.forEach { (k, n) ->
            val t = TextView(this).apply {
                text = n; textSize = 12f
                setPadding(dp(10), dp(4), dp(10), dp(4))
                setOnClickListener {
                    if (k == "ocultos") openHidden() else { filter = k; styleChips(); refreshList() }
                }
            }
            chipViews[k] = t
            row.addView(t, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        styleChips()
        return HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun styleChips() {
        chipViews.forEach { (k, t) ->
            val on = k == filter
            t.setTextColor(if (on) Color.BLACK else Color.WHITE)
            t.background = rr(if (on) accent else 0x33FFFFFF, 0, 0f, 14f)
        }
    }

    private fun refreshList() {
        listBox.removeAllViews()
        val items = visible()
        if (items.isEmpty()) {
            listBox.addView(TextView(this).apply {
                text = "Nenhum app aqui. Ajuste os tipos nas configurações."
                setTextColor(Color.WHITE); textSize = 13f; setPadding(0, dp(24), 0, 0)
            })
            return
        }
        listBox.addView(section(items))
    }

    private fun section(items: List<Item>): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var k = 0
        if (anime) {
            items.forEach { col.addView(row(it, k++)) }
        } else {
            items.chunked(4).forEach { ch ->
                val r = LinearLayout(this)
                ch.forEach { r.addView(tile(it, k++), LinearLayout.LayoutParams(0, -2, 1f)) }
                repeat(4 - ch.size) { r.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
                col.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
        }
        return col
    }

    private fun iconBox(item: Item, size: Int): ImageView {
        val st = Cfg.s("style", "moderno")
        val bg = when {
            Cfg.b("trans", false) -> null
            st == "clean" -> rr(0x24FFFFFF, 0, 0f, 6f)
            st == "futurista" -> rr(Color.argb(140, 0, 0, 0), accent, 1.5f, 2f)
            else -> rr(0x1AFFFFFF, 0x2EFFFFFF, 1f, 14f)
        }
        return ImageView(this).apply {
            setImageDrawable(item.icon)
            background = bg
            scaleType = ImageView.ScaleType.FIT_XY
            setPadding(dp(4), dp(4), dp(4), dp(4))
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
        }
    }

    private fun labelView(item: Item, extra: Int): TextView = TextView(this).apply {
        text = item.label
        textSize = (Cfg.i("ts", 12) + extra).toFloat()
        setTextColor(Color.WHITE)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setShadowLayer(4f, 0f, 1f, Color.argb(150, 0, 0, 0))
        if (Cfg.s("style", "moderno") == "futurista") {
            typeface = Typeface.MONOSPACE
            letterSpacing = 0.04f
        }
    }

    private fun wire(v: View, item: Item, k: Int, dx: Float, dy: Float) {
        v.setOnClickListener { open(item) }
        v.setOnLongClickListener { menu(v, item); true }
        if (Cfg.b("anim", true)) {
            v.alpha = 0f
            v.translationX = dx
            v.translationY = dy
            v.animate().alpha(1f).translationX(0f).translationY(0f)
                .setStartDelay((k.coerceAtMost(15) * 25).toLong()).setDuration(260).start()
            v.setOnTouchListener { x, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> x.animate().scaleX(0.92f).scaleY(0.92f).setStartDelay(0).setDuration(80).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> x.animate().scaleX(1f).scaleY(1f).setStartDelay(0).setDuration(120).start()
                }
                false
            }
        }
    }

    private fun tile(item: Item, k: Int): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        v.addView(iconBox(item, 52))
        v.addView(labelView(item, 0).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        wire(v, item, k, 0f, dp(10).toFloat())
        return v
    }

    private fun row(item: Item, k: Int): View {
        val v = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(5), 0, dp(5)) }
        v.addView(iconBox(item, 36))
        v.addView(labelView(item, 3), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(12) })
        val dx = dp(14).toFloat() * (if (Cfg.s("side", "l") == "l") -1 else 1)
        wire(v, item, k, dx, 0f)
        return v
    }

    // ---------- ações ----------

    private fun open(item: Item) {
        try {
            if (item.pkg != null) {
                packageManager.getLaunchIntentForPackage(item.pkg)?.let { launch(it, Cfg.b("float", false)) }
            } else if (item.url != null) {
                val u = if (item.url.startsWith("http")) item.url else "https://" + item.url
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Não foi possível abrir", Toast.LENGTH_SHORT).show()
        }
    }

    private var cascade = 0

    private fun launch(i: Intent, floating: Boolean) {
        if (!floating) { startActivity(i); return }
        val dm = resources.displayMetrics
        val w = dm.widthPixels * Cfg.i("fw", 70) / 100
        val h = dm.heightPixels * Cfg.i("fh", 60) / 100
        val off = (cascade++ % 5) * dp(28)
        val l = ((dm.widthPixels - w) / 2 + off).coerceAtMost(dm.widthPixels - w)
        val t = ((dm.heightPixels - h) / 3 + off).coerceAtMost(dm.heightPixels - h)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK)
        val o = ActivityOptions.makeBasic().setLaunchBounds(Rect(l, t, l + w, t + h))
        startActivity(i, o.toBundle())
    }

    private fun menu(anchor: View, item: Item) {
        val pm = PopupMenu(this, anchor)
        if (item.pkg != null) {
            pm.menu.add(0, 1, 0, "Informações do app")
            pm.menu.add(0, 2, 1, "Desinstalar")
            pm.menu.add(0, 7, 2, "Abrir em janela flutuante")
            pm.menu.add(0, 5, 3, if (Cfg.hidden().contains(item.pkg)) "Mostrar app" else "Ocultar app")
        } else {
            pm.menu.add(0, 4, 0, "Remover site")
        }
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + item.pkg)))
                2 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + item.pkg)))
                7 -> packageManager.getLaunchIntentForPackage(item.pkg ?: "")?.let { launch(it, true) }
                5 -> {
                    val pk = item.pkg
                    if (pk != null) {
                        val h = Cfg.hidden().toMutableSet()
                        if (!h.remove(pk)) h.add(pk)
                        Cfg.setHidden(h)
                        refreshList()
                    }
                }
                4 -> { Cfg.sites = Cfg.sites.filter { s -> s.second != item.url }; loadApps(); refreshList() }
            }
            true
        }
        pm.show()
    }
}
