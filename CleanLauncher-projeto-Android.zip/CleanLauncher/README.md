# Clean Launcher

Projeto inicial de launcher Android nativo, com interface clean azul, relógio/data, pesquisa e grade automática dos aplicativos instalados.

## Como gerar o APK
1. Abra esta pasta no Android Studio (versão recente).
2. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitado.
3. Selecione **Build > Build APK(s)**.
4. O APK de depuração ficará em `app/build/outputs/apk/debug/app-debug.apk`.
5. Instale o APK e escolha **Clean Launcher** como aplicativo de tela inicial.

O projeto é um protótipo inicial. A pesquisa usa a busca web do Android; o clima, widgets, papéis de parede configuráveis e animações ainda não estão implementados.
