package com.cleanlauncher

import android.app.Activity
import android.app.SearchManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var appGrid: GridLayout
    private val blue = Color.rgb(31, 94, 220)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(20, 67, 150)
        window.navigationBarColor = Color.rgb(8, 26, 69)
        window.decorView.systemUiVisibility = 0
        buildScreen()
        refreshClock()
        loadApps()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(20), dp(22), dp(10))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(17, 66, 150), Color.rgb(76, 132, 238), Color.rgb(82, 73, 190), Color.rgb(8, 32, 91))
            )
        }

        clock = TextView(this).apply {
            textSize = 64f; setTextColor(Color.WHITE); typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        date = TextView(this).apply {
            textSize = 17f; setTextColor(Color.WHITE); alpha = 0.92f
        }
        root.addView(clock, LinearLayout.LayoutParams(-1, dp(82)))
        root.addView(date, LinearLayout.LayoutParams(-1, dp(32)))

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, dp(36)))

        val searchRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(12), 0)
            background = rounded(Color.WHITE, 28)
        }
        val search = EditText(this).apply {
            hint = "Pesquisar aplicativos ou na web"
            textSize = 15f
            setSingleLine(true)
            setBackgroundColor(Color.TRANSPARENT)
            setTextColor(Color.DKGRAY)
            setHintTextColor(Color.GRAY)
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            setOnEditorActionListener { _, _, _ -> doSearch(this.text.toString()); true }
        }
        searchRow.addView(search, LinearLayout.LayoutParams(0, dp(54), 1f))
        val searchButton = TextView(this).apply {
            text = "⌕"; textSize = 30f; setTextColor(blue); gravity = Gravity.CENTER
            setOnClickListener { doSearch(search.text.toString()) }
        }
        searchRow.addView(searchButton, LinearLayout.LayoutParams(dp(42), dp(54)))
        root.addView(searchRow, LinearLayout.LayoutParams(-1, dp(56)))

        val appsTitle = TextView(this).apply {
            text = "Seus aplicativos"; textSize = 17f
            setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(2), dp(24), 0, dp(12))
        }
        root.addView(appsTitle)
        val scroll = ScrollView(this)
        appGrid = GridLayout(this).apply { columnCount = 4; useDefaultMargins = false }
        scroll.addView(appGrid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val footer = TextView(this).apply {
            text = "●     ○     ○"; textSize = 15f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setPadding(0, dp(10), 0, dp(12))
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun refreshClock() {
        val now = Date()
        clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("pt", "BR")).format(now)
        handler.postDelayed({ refreshClock() }, 30_000)
    }

    private fun doSearch(query: String) {
        val intent = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query.ifBlank { " " })
        try { startActivity(intent) } catch (_: Exception) {
            startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(query))))
        }
    }

    @Suppress("DEPRECATION")
    private fun loadApps() {
        appGrid.removeAllViews()
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = packageManager.queryIntentActivities(intent, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase(Locale.getDefault()) }

        for (info in apps) {
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(3), dp(10), dp(3), dp(12))
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                    if (launch != null) startActivity(launch)
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(info.loadIcon(packageManager))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            item.addView(icon, LinearLayout.LayoutParams(dp(48), dp(48)))
            val label = TextView(this).apply {
                text = info.loadLabel(packageManager).toString()
                textSize = 10.5f; setTextColor(Color.WHITE)
                gravity = Gravity.CENTER; maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            }
            item.addView(label, LinearLayout.LayoutParams(-1, dp(34)))
            appGrid.addView(item, GridLayout.LayoutParams().apply {
                width = 0; height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            })
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
